OK_FORMAT = True

test = {   'name': 'q4',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> assert findLeastAmount(\'Campaign_Financial_Contributions_Sample.csv\') == 0.09, "The return value doesn\'t match with the expected value"\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
