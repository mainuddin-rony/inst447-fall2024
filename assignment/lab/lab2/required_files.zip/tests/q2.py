OK_FORMAT = True

test = {   'name': 'q2',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> assert numdoncorp(\'Campaign_Financial_Contributions_Sample.csv\') == 137, "The number of rows doesn\'t match with expected result"\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
