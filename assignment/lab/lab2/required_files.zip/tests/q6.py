OK_FORMAT = True

test = {   'name': 'q6',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> assert findRecentDate(\'Campaign_Financial_Contributions_Sample.csv\') == \'2019-03-13\', "The return date doesn\'t match with the expected '
                                               'date"\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
