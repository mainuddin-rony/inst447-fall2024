OK_FORMAT = True

test = {   'name': 'q5',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> assert findMaxAmount(\'Campaign_Financial_Contributions_Sample.csv\') == 35000.0, "The return value doesn\'t match with the expected value"\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
