OK_FORMAT = True

test = {   'name': 'q1',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> assert array_cal([1, 2, 3], \'mean\') == 2.0, "For input [1,2,3] and \'mean\'\', the function should return 2.0"\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert array_cal([5, 6, 7], \'mean\') == 6.0, "For input [5,6,7] and \'mean\'\', the function should return 3.0"\n', 'hidden': False, 'locked': False},
                                   {   'code': '>>> assert array_cal([5, 6, 7], \'median\') == 6.0, "For input [5,6,7] and \'median\'\', the function should return 6.0"\n',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> assert array_cal([5, 6, 4, 5, 7, 3, 7], \'median\') == 5.0, "For input [5,6,4,5,7,3,7] and \'median\'\', the function should return 5.0"\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
